import math
import time
import random
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
import sys
import psutil
from time import time
from time import sleep
from tkinter import Label
from tkinter import Tk
from tkinter import Button
from tkinter import Canvas
from threading import Thread