import math
import time
import random
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
import sys
import psutil
from time import time
from time import sleep
from tkinter import Label
from tkinter import Tk
from tkinter import Button
from tkinter import Canvas
from threading import Thread
def stone():
    w = "打平"
    e = "电脑赢"
    r = "你赢"
    for i in range(1000):
        print("石头1，剪刀2，布3")
        a = random.choice(("石头", "剪刀", "布"))
        b = input("请出拳")
        b = int(b)
        if (a == "石头"):
            if (b == 1):
                print(w)
                w = "打平\n"
                r2 = open("win.xinxi", "a")
                r2.write(w)
                r2.close()
            elif (b == 2):
                print(e)
                e = "电脑赢\n"
                p = open("win.xinxi", "a")
                p.write(e)
                p.close()

            elif (b == 3):
                print(r)
                r = "你赢\n"
                q2 = open("win.xinxi", "a")
                q2.write(r)
                q2.close()
            else:
                print("输入错误")
                return 0
        elif (a == "剪刀"):
            if (b == 1):
                print(r)
                r = "你赢\n"
                l2 = open("win.xinxi", "a")
                l2.write(r)
                l2.close()
            elif (b == 2):
                print(w)
                w = "打平\n"
                n2 = open("win.xinxi", "a")
                n2.write(w)
                n2.close()
            elif (b == 3):
                print(e)
                e = "电脑赢\n"
                g2 = open("win.xinxi", "a")
                g2.write(e)
                g2.close()
            else:
                print("输入错误")
                return 0
        elif (a == "布"):
            if (b == 1):
                print(e)
                e = "电脑赢\n"
                u2 = open("win.xinxi", "a")
                u2.write(e)
                u2.close()
            elif (b == 2):
                print(r)

                r = "你赢\n"
                q2 = open("win.xinxi", "a")
                q2.write(r)
                q2.close()
         
            elif (b == 3):
                print(w)
                w = "打平\n"
                y2 = open("win.xinxi", "a")
                y2.write(w)
                y2.close()
            else:
                print("输入错误")
                return 0
def write():
    q2 = open("信息.xinxi", "a")
    xinxi = input("加入信息")
    xin = xinxi +'\n'
    q2.write(xin)
    q2.close()
    print("写入成功")
def read():
    cho = input("请选择: 1.信息 2.石头剪刀布战绩")
    if cho == "1":
        w1 = open("信息.xinxi", "r")
        g = w1.read()
        w1.close()
        print(g)
        return 0
    elif cho == "2":
            try:
                r1 = open("win.xinxi", "r")
                q = r1.read()
                r1.close()
                print(q)
                return 0
            except:
                print("您未进行石头剪刀布游戏")
                return 0 
def scsuiji():
    import os
    min1=int(input('请输入最小值:'))
    max1=int(input('请输入最大值:'))
    r1=random.randint(min1,max1)
    print(r1)
    time.sleep(2)
def csuiji():
    i=1
    s1=random.randint(0,100)
    cs1=int(input('请输入1~100中的一个数字:'))
    while s1!=cs1:
        if s1>cs1:
            print('你第'+str(i)+'次输入的数字小于随机数字')
            cs1=int(input('再试一次吧:'))
        else:
            print('你第'+str(i)+'次输入的数字大于随机数字')
            cs1=int(input('再试一次吧:'))
        i+=1
    print('恭喜你,你第'+str(i)+'次输入的数字与随机数字一样!')
    time.sleep(16)
def clock():
    while True:
        print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        time.sleep(1)
        os.system('cls')
def ZLOSabout():
    print('\n++++++++++++++++++++++')
    print('       ===ZLOS===\n')
    print('       by cwpy56 \n')
    print(' Version : v2.0 Release\n')
    print('++++++++++++++++++++++\n')
    return 0
def PC():
     def GUI_Init():
          global T1,T2,T3,T4,T5
          global Map,l7
          l1 = Label(root, text='开机时长:',fg = "lightgreen",bg = "black")
          l1.pack()
          l1.place(x=10,y=10,width=80,height=30)
          T1 = Label(root, text=0,fg = "yellow",bg = "black")
          T1.pack()
          T1.place(x=90,y=10,width=300,height=30)

          l2 = Label(root, text='CPU使用率:',fg = "lightgreen",bg = "black")
          l2.pack()
          l2.place(x=10,y=70,width=80,height=30)
          T2 = Label(root, text=0,fg = "yellow",bg = "black")
          T2.pack()
          T2.place(x=90,y=70,width=300,height=30)

          l3 = Label(root, text='网速流量:',fg = "lightgreen",bg = "black")
          l3.pack()
          l3.place(x=10,y=130,width=80,height=30)
          T3 = Label(root, text=0,fg = "yellow",bg = "black")
          T3.pack()
          T3.place(x=90,y=130,width=300,height=30)

          l4 = Label(root, text='内存占用:',fg = "lightgreen",bg = "black")
          l4.pack()
          l4.place(x=10,y=190,width=80,height=30)
          T4 = Label(root, text=0,fg = "yellow",bg = "black")
          T4.pack()
          T4.place(x=90,y=190,width=300,height=30)

          l5 = Label(root, text='交换内存:',fg = "lightgreen",bg = "black")
          l5.pack()
          l5.place(x=10,y=250,width=80,height=30)
          T5 = Label(root, text=0,fg = "yellow",bg = "black")
          T5.pack()
          T5.place(x=90,y=250,width=300,height=30)

          l6 = Label(root, text=u'\u25BA',fg = "white",bg = "black",font = "Helvetica 16 bold")
          l6.pack()
          l6.place(x=390,y=70,width=30,height=30)

          Map = Canvas(root,width=300,height=265,bg = "lightgray")
          Map.pack()
          Map.place(x=420,y=10)

          l7 = Label(root, text='',fg = "blue",bg = "lightgray")
          l7.pack()
          l7.place(x=680,y=12,width=36,height=16)

     def Run():
          var = 1
          color = 'red'
          global Lisdraw
          Lisdraw = list()
          LNS = psutil.net_io_counters().bytes_sent
          LNR = psutil.net_io_counters().bytes_recv
          while var == 1:
               Time = int(time() - psutil.boot_time())
               T1['text'] = str(int(Time/3600))+"h-"+str(int(Time/60)%60)+"min-"+str(Time%60)+"s"

               CPU_Pec = psutil.cpu_percent(0)
               T2['text'] = str(CPU_Pec)+"%\t"+str(round(psutil.cpu_freq().current/1000,3))+"GHz"

               NetS = psutil.net_io_counters().bytes_sent
               NetR= psutil.net_io_counters().bytes_recv
               T3['text'] = str(round((NetS-LNS)*2/1024,2))+"Kb/s"+u'\u21E7'+"     "+str(round((NetR-LNR)*2/1024,2))+"Kb/s"u'\u21E9'+"     Data:"+str(round((NetS+NetR)/1024/1024,2))+"Mb"+u'\u21C5'

               MemAll = round(psutil.virtual_memory().total/1024/1024,2)
               MemUse = round(psutil.virtual_memory().used/1024/1024,2)
               MemPec = psutil.virtual_memory().percent
               T4['text'] = str(MemUse)+"Mb"+"/"+str(MemAll)+"Mb"+"  "+str(MemPec)+"%"

               SwapMemAll = round(psutil.swap_memory().total/1024/1024,2)
               SwapMemUsed = round(psutil.swap_memory().used/1024/1024,2)
               SwapMemPec = psutil.swap_memory().percent
               T5['text'] = str(SwapMemUsed)+"Mb"+"/"+str(SwapMemAll)+"Mb"+"  "+str(SwapMemPec)+"%"

               if mode == 0:
                    color = 'red'
                    Het = int(CPU_Pec*260/100)
               elif mode == 1:
                    Het = int((NetS-LNS)*2/1024) + int((NetR-LNR)*2/1024)
               elif mode == 2:
                    color = 'green'
                    Het = int(MemPec*260/100)
               elif mode == 3:
                    color = 'orange'
                    Het = int(SwapMemPec*260/100)
               Lisdraw.append(Het)
               if len(Lisdraw) == 61:
                    del Lisdraw[0]
               Map.delete("all")

               if mode != 1 and len(Lisdraw) > 2:
                    l7['text'] = ''
                    l7['text'] = '100%'
                    for i in range(0,len(Lisdraw)-1):
                         Map.create_line(i*5,260-Lisdraw[i],i*5+5,260-Lisdraw[i+1],fill=color,width = 2)
               if mode == 1 and len(Lisdraw) > 2:
                    l7['text'] = ''
                    if max(Lisdraw) < 100:
                         l7['text'] = '100Kb'
                         for i in range(0,len(Lisdraw)-1):
                              Map.create_line(i*5,260-Lisdraw[i]*260/100,i*5+5,260-Lisdraw[i+1]*260/100,fill='skyblue',width = 2)
                    elif max(Lisdraw) < 1000:
                         l7['text'] = '1Mb'
                         for i in range(0,len(Lisdraw)-1):
                              Map.create_line(i*5,260-Lisdraw[i]*260/1000,i*5+5,260-Lisdraw[i+1]*260/1000,fill='blue',width = 2)
                    elif max(Lisdraw) < 10000:
                         l7['text'] = '10Mb'
                         for i in range(0,len(Lisdraw)-1):
                              Map.create_line(i*5,260-Lisdraw[i]*260/10000,i*5+5,260-Lisdraw[i+1]*260/10000,fill='purple',width = 2)
                    elif max(Lisdraw) < 100000:
                         l7['text'] = '50Mb'
                         for i in range(0,len(Lisdraw)-1):
                              Map.create_line(i*5,260-Lisdraw[i]*260/50000,i*5+5,260-Lisdraw[i+1]*260/50000,fill='red',width = 2)
               sleep(0.5)
               LNS = NetS
               LNR = NetR
               root.protocol('WM_DELETE_WINDOW',End)

     def Mode():
          global mode
          global Lisdraw
          l6 = Label(root, text="",bg = "black")
          l6.place(x=390,y=10+(mode+1)*60,width=30,height=30)
          l7['text'] = ''
          mode = mode+1
          if mode == 4:
               mode = 0
          if mode == 0:
               l6 = Label(root, text=u'\u25BA',fg = "white",bg = "black",font = "Helvetica 16 bold italic")
               l6.place(x=390,y=70,width=30,height=30)
          elif mode == 1:
               l6 = Label(root, text=u'\u25BA',fg = "white",bg = "black",font = "Helvetica 16 bold italic")
               l6.place(x=390,y=130,width=30,height=30)
          elif mode == 2:
               l6 = Label(root, text=u'\u25BA',fg = "white",bg = "black",font = "Helvetica 16 bold italic")
               l6.place(x=390,y=190,width=30,height=30)
          elif mode == 3:
               l6 = Label(root, text=u'\u25BA',fg = "white",bg = "black",font = "Helvetica 16 bold italic")
               l6.place(x=390,y=250,width=30,height=30)
          Lisdraw = list()
          Map.delete("all")

     def End():
          root.destroy()

     if __name__ == '__main__':
          mode = 0
          root = Tk()
          root.title("PC监视器")
          root.geometry('750x300')
          root.configure(background = 'black')
          GUI_Init()
          TIM = Thread(target = Run)
          TIM.daemon = True
          TIM.start()
          Button1 = Button(root, text=u'\u25B2'+u'\u25BC', command = Mode,bg = "pink")
          Button1.pack()
          Button1.place(x=390,y=10,width=30)
          root.mainloop()
def start():            
        ZLOS=input('ZLOS 选择应用: 1.随机数生成器(原创) 2.猜随机数(原创) 3.时钟 4.exit\n5.写入信息 6.读取信息 7.石头剪刀布 8.About 9.PC监视器')
        global write
        global read
        if ZLOS == str(1):
                scsuiji()
        elif ZLOS == str(2):
                csuiji()
        elif ZLOS == str(3):
                clock()
        elif ZLOS == str(4):
                exit()
        elif ZLOS == str(5):
                write()
        elif ZLOS == str(6):
                read()
        elif ZLOS == str(7):
                stone()
        elif ZLOS == str(8):
                ZLOSabout()
        elif ZLOS == str(9):
                PC()
        else:
                return 0
while True:
        start()
